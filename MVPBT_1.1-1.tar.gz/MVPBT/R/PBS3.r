# Parametric resampling function from the estimated distribution (by constrained ML)

PBS3 <- function(y,S,b0,V0){

	N <- dim(y)[1]
	p <- dim(y)[2]

	y.pb <- matrix(numeric(N*p),N)

	for(i in 1:N){

		yi <- y[i,]
		Si <- matrix(c(S[i,1],S[i,2],S[i,2],S[i,3]),p)

		Vi <- Si + V0

		Xi <- diag( sqrt(diag(Si) + diag(V0))^-1 )
		Psii <- Xi %*% Vi %*% t(Xi)

		mui <- Xi %*% b0

		y.pb[i,] <- ginv(Xi) %*% mvrnorm(1, mui, Psii)

	}
		
	return(y.pb)
	
}

